#ifndef partie3_h
#define partie3_h
#include <stdio.h>

int taille_tableau_de_noeud(Noeud );
Noeud recherche_dichotomie_tableau_noeuds(Noeud , char );
void ajout_occurrence();
void affichage_tableau_de_noeuds(Noeud );



#endif /* partie3_h */
