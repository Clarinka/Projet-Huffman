#include "partie2.h"
#include "partie3.h"
#include <stdlib.h>



/*int taille_tableau_de_noeud(Noeud tab)
{
    Noeud temp = tab;
    int i = 0;

    if(tab == NULL){
        return i;
    }
    else{
        while(temp != NULL){
            i = i+1;
            temp = temp + 1;
        }
        return i;
    }
}

Noeud recherche_dichotomie_tableau_noeuds(Noeud tab, char caractere)
{
    int d=0, m;
    int dim;
    Noeud temp,temp2;


    if(tab == NULL){
        tab[0] = creer_noeud(caractere,1);
        return tab;
    }

    else{
        dim = taille_tableau_de_noeud(tab);
    while (dim>d){

        m = (d+dim)/2;

        if ('caractere' > '(tab+m)->lettre'){
            d = m;
        }
        else if ('caractere' < 'tab[m]->lettre'){
            dim = m;
        }
        else if('caractere' == 'tab[m]->lettre'){
            (tab+m)->poids = (tab+m)->poids + 1;
            return tab;
        }
    }
    tableau = (Noeud*)malloc((sizeof(Noeud));
    if ('caractere' > 'tab[m]->lettre'){
        temp = creer_noeud(caractere,1);

        temp2 = (tab+m+1);

        }
    else if ('caractere' < 'tab[m]->lettre'){
            dim = m;
        }
    }


}*/

/*Noeud* recherche_dichotomie_tableau_noeuds(Noeud** tab, char caractere)
{
    int d=0, m;
    int dim;
    Noeud* temp,temp2;


    if(*tab == NULL){
        *tab = (Noeud*)malloc((sizeof(Noeud));
        *tab = creer_noeud(caractere,1);
        return tab;
    }

    else{
        dim = taille_tableau_de_noeud(*tab);
        while (dim>d){

            m = (d+dim)/2;

            if ('caractere' > 'tab->lettre'){

                d = m;
            }
            else if ('caractere' < 'tab->lettre'){
                dim = m;
            }
            else if('caractere' == 'tab->lettre'){
                tab->poids = tab->poids + 1;
                return tab;
            }
        }

        temp = (Noeud*)malloc((sizeof(Noeud));
        if ('caractere' > 'tab->lettre'){
            temp = creer_noeud(caractere,1);

            temp2 = (tab+m+1);

            }
        else if ('caractere' < 'tab[m]->lettre'){
            dim = m;
            }
    }


}

void ajout_occurrence()
{
    Noeud tableau = NULL;
    char caractere;


    FILE* fichier = fopen("Alice.txt", "r");
    if(fichier == NULL){
        printf("ERREUR DE LECTURE DE FICHIER");
        }
    else{
        do{
            fseek(fichier,0,SEEK_CUR);
            //on lit le fichier Alice.txt qu'on va mettre dans le tableau de noeuds
            caractere = fgetc(fichier2);
            recherche_dichotomie_tableau_noeuds(tableau,caractere);

        }while (caractere!=EOF);
    }

    fclose(fichier);

}

void affichage_tableau_de_noeuds(Noeud tab)
{
    int i,
    for (i = 0; i < 200; i++){
        printf("%c ", tab[i]->lettre);
        printf("\n");
    }
}
*/
