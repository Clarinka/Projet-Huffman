#ifndef partie2_h
#define partie2_h
#include <stdio.h>


typedef struct Element
{
    int occurrence;
    char lettre;
    struct Element* next;

}Element;

typedef struct Noeud
{
    int poids;
    char lettre;
    struct Noeud* next;
    struct Noeud* left;
    struct Noeud* right;

}Noeud;


Element* creer_Element(char );
void liberer_liste(Element** );
void liberer_liste_de_noeuds(Noeud** );
void ajouter_valeur_liste_fin(Element* ,char );
void ajouter_un_a_occurence(Element* );
void afficher_Liste(Element* );
Element* condition_liste_caracteres_occurrences(Element* , char );
Element* occurrence_caractere();
Noeud* creer_noeud(int , char );
int min_liste(Element* );
int position_min_liste(Element* , int );
void supprimer_maillon_liste(Element** , int );
void afficher_Liste_de_noeuds(Noeud* );
Noeud* creation_liste_de_noeud(Element* ,int );
void inverser_liste(Noeud ** );
void fichier_texte_arbre_Huffman(Noeud* );
void dico_recherche(char ,FILE** ,FILE* );
void trad_text_bin_huffman();


#endif /* partie2_h */
