#ifndef texte_h
#define texte_h
#include <stdio.h>


void convertir_binaire(int* ,char* );
void equivalent_fichier_texte();
int compter_carac_txt();
int compter_carac_txt_bin();



#endif /* texte_h */
