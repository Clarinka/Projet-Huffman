#ifndef partie3_h
#define partie3_h
#include <stdio.h>

void ajouter_un_a_occurence_de_tableau_de_noeuds(Noeud );
Noeud* recherche_dichotomie_tableau_noeuds(Noeud , char );
void ajout_occurrence();
void affichage_tableau_de_noeuds(Noeud );



#endif /* partie3_h */
